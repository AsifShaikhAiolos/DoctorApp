# Acknowledgements

This software includes the following software dependencies under their corresponding licenses:

- Twilio Video Android - https://www.twilio.com/legal/tos.

- Generic [Apache 2.0 License](https://www.apache.org/licenses/LICENSE-2.0.txt).

    - Timber
    - MaterialRangeBar
    - Butter Knife
    - Guava
    - Dagger
    - RxJava
    - Retrofit
    - Kotlin

Android SDK and Google Libraries - https://developer.android.com/studio/terms.html.

Firebase - https://cloud.google.com/terms/.

Crashlytics - https://firebase.google.com/terms/crashlytics/.
