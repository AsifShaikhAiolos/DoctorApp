package com.twilio.video.app.auth

interface LoginResult
