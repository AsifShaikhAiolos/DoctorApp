package com.twilio.video.app

import android.app.Application

fun startAppcenter(application: Application) {}
