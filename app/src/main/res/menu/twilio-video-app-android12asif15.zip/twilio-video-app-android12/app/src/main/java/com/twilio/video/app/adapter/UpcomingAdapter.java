package com.twilio.video.app.adapter;

public class UpcomingAdapter {
}
