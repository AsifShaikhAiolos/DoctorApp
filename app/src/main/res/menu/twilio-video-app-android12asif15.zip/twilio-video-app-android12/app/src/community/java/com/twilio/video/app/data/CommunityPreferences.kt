package com.twilio.video.app.data

const val PASSCODE: String = "passcode"
