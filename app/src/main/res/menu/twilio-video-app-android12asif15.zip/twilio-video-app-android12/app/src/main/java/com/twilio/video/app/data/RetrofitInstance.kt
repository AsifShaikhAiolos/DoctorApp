package com.aiolos.solutions.doctorconsult.data

object RetrofitInstance {
}