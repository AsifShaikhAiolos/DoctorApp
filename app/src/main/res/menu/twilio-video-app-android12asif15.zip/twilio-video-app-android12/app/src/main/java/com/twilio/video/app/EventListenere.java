package com.twilio.video.app;

import android.view.View;

public interface EventListenere {
    void onClick( int position);
}
