package com.aiolos.solutions.doctorconsult.data

interface NetworkApiInterface {
}