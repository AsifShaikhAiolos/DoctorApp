package com.twilio.video.app.auth

// TODO Provide more detailed error handling as part of https://issues.corp.twilio.com/browse/AHOYAPPS-153
class AuthenticationException : Exception()
