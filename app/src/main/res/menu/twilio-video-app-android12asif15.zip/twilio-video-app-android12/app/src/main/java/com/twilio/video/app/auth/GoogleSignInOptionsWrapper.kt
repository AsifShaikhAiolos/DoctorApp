package com.twilio.video.app.auth

import com.google.android.gms.auth.api.signin.GoogleSignInOptions

class GoogleSignInOptionsWrapper(val googleSignInOptions: GoogleSignInOptions)
